#include<iostream>
using namespace std;
#include"complexcalculator.h"
ComplexNumbers::ComplexNumbers()
{
	this->real = 0;
	this->img = 0;
}
ComplexNumbers::ComplexNumbers(int real, int img)
{

	this->real = real;
	this->img = img;
}
void ComplexNumbers::setreal(int real)
{
	this->real = real;
}
void ComplexNumbers::setimg(int img)
{

	this->img = img;
}
int ComplexNumbers::getreal()
{

	return this->real;
}
int ComplexNumbers::getimg()
{

	return this->img;
}
ComplexNumbers ComplexNumbers::operator+(ComplexNumbers&obj2)
{
	ComplexNumbers ans;
	ans.real = this->real + obj2.real;
	ans.img = this->img + obj2.img;
	return ans;
}
void ComplexNumbers::display()
{
	 
	
	cout << this->real << "+" << this->img << "i" << endl;

}
ComplexNumbers ComplexNumbers::operator-(ComplexNumbers&obj2)
{
	ComplexNumbers ans;
	ans.real = this->real - obj2.real;
	ans.img = this->img - obj2.img;
	return ans;
}
void main()
{
	ComplexNumbers obj1, obj2, ans;
	obj1.setreal(2);

	obj1.setimg(3);

	obj1.display();
	obj2.setreal(3);
	
	obj2.setimg(4);
	
	obj2.display();

	ans = obj1 + obj2;
	
	ans.display();
	ans = obj1 - obj2;
	ans.display();
	getchar();
	fflush(stdin);
}