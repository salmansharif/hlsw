#include<iostream>

using namespace std;

class IntegerSet
{
	// attributes
    private: int set[101];

    
    // constructors

    //1- default
    public: IntegerSet()
			{
			   for(int x=0;x<101;x++)
			   {
				   this->set[x] = 0;
			   }
			}

    //2- Parametarized
     public: IntegerSet(int arr[], int size)
			{    
				 for(int x=0;x<101;x++)
			     {
				   this->set[x] = 0;
			     }

			     for(int x=0;x<size;x++)
				 {
					 this->set[arr[x]] = 1;
				 }
			}


    // class Member functions
	public: void insertElement(int K)
			{
				this->set[K]=1;
			}
	public: void deleteElement(int K)
			{
				this->set[K]=0;
			}

	public: void printSet()
			{
			    for(int x=0;x<101;x++)
				{
					if(this->set[x] == 1)
					{
					  cout<<x<<" ";
					}
				}
			
				cout<<endl;
			}


     // Set Functions
     // 1 - Union Function
     public: IntegerSet unionOf_Sets(IntegerSet *S)
			 {
			     IntegerSet temp;

				 for(int x=0;x<101;x++)
				 {
					 if(this->set[x] == 1 || S->set[x] == 1 )
					 {
						 temp.set[x] = 1;
					 }
					 else
					 {
						 temp.set[x] = 0;
					 }
				 }


				    return temp;
			 }
     public: IntegerSet intersectionOfSets(IntegerSet *S)
			 {
                   IntegerSet temp;
	
				 for(int x=0;x<101;x++)
				 {
					 if(this->set[x] == 0 || S->set[x] == 0)
					 {
						 temp.set[x] = 0;
					 }
					 else
					 {
						 temp.set[x] = 1;
					 }
				 }


				    return temp;				
			 }



     public: void isEqualTo(IntegerSet *S)
			 { 
				 int flg=0;
			 
				 for(int x=0;x<101;x++)
				 {
					 if(S->set[x] != this->set[x])
					 {
                        
					   cout<<"Sets Are Not Equal !"<<endl;
					   flg++;
					   break;
					 }
				 }
			 
				 if(flg == 0)
				 {
				   cout<<"Sets are Equal "<<endl;
				 }

			 }


};



int main()
{
	
	 //Default Constructor The default constructor initializes a set to
     //the so-called �empty set,� i.e., a set for which all elements 
     //contain false

	  IntegerSet S1;
	  // Print Set function
	  cout<<"\nS1 Created By default Constructor all bool values false so prints nothing"<<endl<<endl<<"S1 == ";
	  S1.printSet();

     //Provide an additional constructor that receives an array of integers 
	 //and the size of that array and uses the array to initialize a set object. 

	  int arr[10]={24,2,11,19,99,67,86,45,37,100};
	  IntegerSet *S2 = new IntegerSet(arr,10);
	  // Print Set function
	  cout<<"\nS2 new Object Created by perametarized Constructor by Passing array of size 10"<<endl<<endl<<"S2 == ";
	  S2->printSet();

	  //Provide an insertElement member function that places a new integer k 
	  //into a set by setting a[k] to true. 
	  cout<<"\nS1 after using Insert Element Function adding values {100,25,50,45,24} "<<endl<<endl<<"S1 == ";

	  S1.insertElement(100);
	  S1.insertElement(25);
	  S1.insertElement(50);
	  S1.insertElement(45);
	  S1.insertElement(24);
	  
	  // Print Set function
	  S1.printSet();

	  //Provide a deleteElement member function that deletes integer m by 
	  //setting a[m] to false.

	  S1.deleteElement(24);
      // Print Set function
	  cout<<"\nS1 after deleting value 24 by using delete Element function"<<endl<<endl<<"S1 == ";
	  S1.printSet();
	 

	  //provide a unionOf-Sets member function that creates a third set that 
	  //is the set-theoretic union of two existing sets (i.e., an element of the 
	  //result is set to true if that element is true in either or both of the existing 
	  //sets, and an element of the result is set to false if that element is false in each 
	  //of the existing sets).

	  IntegerSet S3;
	  cout<<"\nUnion Function of Set S1 by passing S2 Object"<<endl;
	  S3=S1.unionOf_Sets(S2);
	  cout<<"Resultant Set S3 == ";
	  S3.printSet();


	  //Provide an intersectionOfSets member function which creates a third set which 
	  //is the settheoretic intersection of two existing sets (i.e., an element of the 
	  //result is set to false if that element is false in either or both of the existing sets, 
	  //and an element of the result is set to true if that element is true in each of the 
	  //existing sets)

	  IntegerSet S4;
	  cout<<"\nIntersection Function of Set S3 by passing S1 Object"<<endl;
	  S4=S3.intersectionOfSets(&S1);
	  cout<<"Resultant Set S4 == ";
	  S4.printSet();


	  //Provide an isEqualTo member function that determines whether two sets are equal
	  cout<<"\nIsEqualTo function of S4 by passing S3"<<endl<<endl;
	  S4.isEqualTo(&S3);
	  cout<<"\nIsEqualTo function of S1 by passing S4"<<endl<<endl;
	  S1.isEqualTo(&S4);
fflush(stdin);
getchar();
return 0;
}