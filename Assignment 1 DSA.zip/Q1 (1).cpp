#include<iostream>
#include<ctime>
#include<string>

using namespace std;


class HeartRate
{

   // Member Attributes of class 
   private: string first_name;
   private: string Last_name;
   private: int B_day;
   private: int B_Month;
   private: int B_Year;
   private: int age;
   private: int Max_rate;
   private: int Target_rate;
   // Parametarize Constructor of Class

   public: HeartRate(string first_name, string Last_name, int B_day,int B_Month,int B_Year)
		   {
			   this->first_name= first_name;
			   this->Last_name=Last_name;
			   this->B_day=B_day;
			   this->B_Month=B_Month;
			   this->B_Year=B_Year;
		   }
    // Setter Methods of Class 

   public: void Set_First_Name(string first_name)
           {
			   this->first_name=first_name;

           }
   public: void Set_Last_Name(string Last_name)
           {
			   this->Last_name=Last_name;

           }
   public: void Set_Date_of_Birth(int B_day,int B_Month,int B_year)
		   {
			   this->B_day=B_day;
			   this->B_Month=B_Month;
			   this->B_Year=B_Year;
		   }

    // Getter Methods of Class
 
	public: string Get_First_Name()
			{
				return this->first_name;
			}

	public: string Get_Last_Name()
			{
				return this->Last_name;
			}
    public: int Get_B_Day()
			{
				return this->B_day;
			}
    public: int Get_Month()
			{
				return this->B_Month;
			}    
    public: int Get_B_Year()
			{
				return this->B_Year;
			}


      
	public: int getAge()
			{
			    int c_year;

			         time_t t = time( NULL );
                     struct tm today = *localtime( &t );
	                 c_year= today.tm_year + 1900;




					 age = (c_year - (this->B_Year));
			

				return age;
			}
    public: int getMaxiumumHeartRate()
			{
			
				Max_rate =  220 - this->age;
			
			        return Max_rate;
			}
    public: int getTargetHeartRate()
			{
			    int temp1, temp2;

				temp1 = (this->Max_rate * 50) / 100;
			    temp2 = (this->Max_rate * 85) / 100;

				this->Target_rate = (temp1 + temp2) / 2;

			
				return this->Max_rate;
			}



};


int main()
{
	 string f_Name, L_Name;
	 int B_day, B_Month,B_Year;


	 cout<<"                    Heart-Rate Monitor "<<endl<<endl;

	     cout<<"Information Required         "<<endl<<endl;

	 cout<<"Enter Your First Name == ";
	 fflush(stdin);
	 getline(cin,f_Name);
	 cout<<"Enter Your Last Name == ";
	 fflush(stdin);
	 getline(cin,L_Name);

	 cout<<"Enter your Birth Day == ";
	 cin>>B_day;
	 cout<<"Enter your Birth Month == ";
	 cin>>B_Month;
	 cout<<"Enter your Birth Year == ";
	 cin>>B_Year;

     HeartRate  person(f_Name,L_Name,B_day,B_Month,B_Year);

	 cout<<"Press Enter To Continue ->  "<<endl;
	 cin.ignore();
	 getchar();
	 system("cls");

	 cout<<"                    Heart-Rate Monitor "<<endl<<endl;

	 cout<<"First Name == "<<person.Get_First_Name()<<endl;
	 cout<<"Last Name == "<<person.Get_Last_Name()<<endl;
	 cout<<"Date Of Birth == "<<person.Get_B_Day()<<" - "<<person.Get_Month()<<" - "<<person.Get_B_Year()<<endl;
	 cout<<"Age in years == "<<person.getAge()<<endl;
	 cout<<"Max Heart Rate == "<<person.getMaxiumumHeartRate()<<endl;
	 cout<<"Target Heart Rate == "<<person.getTargetHeartRate()<<endl<<endl;


	 cout<<"Press Enter to Exit ->"<<endl;




fflush(stdin);
getchar();
return 0;
}