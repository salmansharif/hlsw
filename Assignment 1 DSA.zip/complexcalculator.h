#include<iostream>
using namespace std;

class ComplexNumbers
{
private:
	int real;
	int img;
public:
	ComplexNumbers();
	ComplexNumbers(int real, int img);
	void setreal(int real);

	void setimg(int img);
	int getreal();
	int getimg();
	void display();
	ComplexNumbers operator+(ComplexNumbers &obj2);
	ComplexNumbers operator-(ComplexNumbers&obj2);
};
